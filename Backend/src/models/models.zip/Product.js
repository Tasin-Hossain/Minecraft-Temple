import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    slug: { type: String, unique: true },

    description: { type: String, required: true },

    shortDescription: { type: String },

    category: {
      type: String, // e.g. Minecraft, Roblox, Website
      required: true,
    },

    subCategory: String, // Plugins, Builds, Themes etc

    price: { type: Number, default: 0 }, // base price

    currency: { type: String, default: "USD" },

    isFree: { type: Boolean, default: false },

    thumbnail: { type: String },

    gallery: [String],

    tags: [String],

    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    downloadPermissions: {
      roles: {
        type: [String],
        enum: ["member", "moderator", "admin"],
        default: ["member"], 
      },

      purchaseRequired: {
        type: Boolean,
        default: true,
      },
    },

    status: {
      type: String,
      enum: ["draft", "pending", "approved", "rejected"],
      default: "pending",
    },

    stats: {
      views:{ type: Number, default: 0},
      downloads: { type: Number, default: 0 },
      purchases: { type: Number, default: 0 },
      reviews: { type: Number, default: 0 },
      rating: { type: Number, default: 0 },
    },

    supportThread: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Thread", // forum support thread
    },
  },
  { timestamps: true }
);

/* ✅ INDEXES HERE */
productSchema.index({
  title: "text",
  description: "text",
  tags: "text",
});

productSchema.index({
  status: 1,
  category: 1,
});

export default mongoose.model("Product", productSchema);

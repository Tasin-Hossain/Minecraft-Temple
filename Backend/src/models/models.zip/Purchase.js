const purchaseSchema = new mongoose.Schema(
  {
    buyer: { type: mongoose.Schema.Types.ObjectId, ref: "User" },

    product: { type: mongoose.Schema.Types.ObjectId, ref: "ProductVersion" },

    price: Number,

    status: {
      type: String,
      enum: ["completed", "refunded"],
      default: "completed",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Purchase", purchaseSchema);

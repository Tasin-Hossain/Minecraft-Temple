const profileSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", unique: true },

    bio: String,
    location: String,
    website: String,
    socialLinks: {
      twitter: String,
      discord: String,
      github: String,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Profile", profileSchema);
